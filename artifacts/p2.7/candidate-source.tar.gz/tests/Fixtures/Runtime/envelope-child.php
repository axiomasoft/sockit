<?php

declare(strict_types=1);

require dirname(__DIR__, 3).'/vendor/autoload.php';

use Illuminate\Database\Events\QueryExecuted;
use SocKit\Audience\Contracts\ActionAuthorizer;
use SocKit\Operations\Data\CommandEnvelope;
use SocKit\Support\Data\CommandKey;
use SocKit\Support\Data\CommandNamespace;
use SocKit\Support\Data\Revision;
use SocKit\Surfaces\SurfaceInstances;
use SocKit\Tests\Fixtures\Runtime\EnvelopeAuthority;
use SocKit\Tests\Fixtures\Runtime\EnvelopeScenario;

$s = new EnvelopeScenario(install: false);
$connection = $s->base->db->capsule->getConnection('owner_a');
$connection->statement("SET statement_timeout='10s'");
$authority = new EnvelopeAuthority($connection);
$s->base->app->instance(abstract: ActionAuthorizer::class, instance: $authority);
$pid = $connection->scalar('SELECT pg_backend_pid()');
if (! is_int($pid)) {
    throw new RuntimeException('Invalid contender backend PID');
}
fwrite(STDOUT, $pid.PHP_EOL);
fflush(STDOUT);
$role = $argv[1];
$mode = $argv[2];
$held = false;
if ($role === 'hold') {
    $connection->listen(function (QueryExecuted $query) use (&$held, $mode): void {
        if (! $held && str_starts_with($query->sql, 'update') && (str_contains($query->sql, 'envelope_state') || (in_array($mode, ['archive', 'delete'], true) && str_contains($query->sql, 'a_surface_instances')))) {
            $held = true;
            fwrite(STDOUT, "claimed\n");
            fflush(STDOUT);
            stream_set_timeout(STDIN, 10);
            if (trim((string) fgets(STDIN)) !== 'release') {
                throw new RuntimeException('Missing envelope barrier');
            }
            if ($mode === 'rollback') {
                throw new RuntimeException('injected winner rollback');
            }
        }
    });
}
if ($role === 'wait' && $mode === 'digest') {
    $s->mutation->value = 2;
}
if ($role === 'hold' && in_array($mode, ['archive', 'delete'], true)) {
    $lifecycle = $s->base->app->make(SurfaceInstances::class);
    $command = new CommandEnvelope(key: new CommandKey('req.2026-10-28.lifecycle'), namespace: new CommandNamespace(installation: $s->handle->actor->installation, panel: $s->handle->surface->panel, integration: 'acme.client', commandType: 'sockit.surfaces.'.$mode),
        digest: $lifecycle->digest(handle: $s->handle, action: $mode, expectedRevision: new Revision(1)), expectedRevision: new Revision(1));
    $result = $lifecycle->$mode(handle: $s->handle, command: $command);
} else {
    $key = $mode === 'cas' && $role === 'wait' ? 'req.2026-10-28.cas2' : 'req.2026-10-28.0001';
    $result = $s->execute($s->command(key: $key));
}
if ($role === 'lost') {
    $connection->disconnect();
    fwrite(STDERR, "P2.7 lost response after REAL commit; no outcome returned\n");
    exit(0);
}
fwrite(STDOUT, json_encode(['result' => $result->toWire(), 'writes' => $s->mutation->writes, 'resolvers' => $s->target->levels, 'authority' => $authority->levels, 'level' => $connection->transactionLevel()], JSON_THROW_ON_ERROR).PHP_EOL);
